/**
 * Created by Novaflo02 on 2022-07-04.
 */

$(function(){
    console.log('sendVoC Ready');
})


function sendVoC (){
    let form = new FormData();
    form.append('name', name);
    form.append('phone1', '000');
    form.append('phone2', '0000');
    form.append('phone3', '0000');
    form.append('emailname', '');
    form.append('emailhost', '');
    form.append('emailhost_auto', '');
    form.append('wish_time', '');
    form.append('category_id', '7');
    form.append('content', $('input[name=B_TITLE]').val() + $('input[name=B_CONTENT]').val() );
    form.append('is_personal_aggre', '1');
    form.append('is_agree', '0');
    consult.sendModalForm(form);

}

